<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	    
	    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<title>GRUNGE</title>
		<link rel="icon" type="image/x-icon" href="images/favicon.ico" />
		
		<link href="css/style1.css" rel="stylesheet" type="text/css" />
			
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
		<link href="css/Slideshow1.css" rel="stylesheet" type="text/css" />	
		<link href="css/ImageOverdayTitle1.css" rel="stylesheet" type="text/css" />	
		<link href="css/icon.css" rel="stylesheet" type="text/css" />	
		
		<link href="css/sidenav.css" rel='stylesheet' type='text/css' />
		
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

		
		
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>

		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="js/jquery.min.js"></script>
		 <!-- Custom Theme files -->
	
   		 <!-- Custom Theme files -->
   		 <!---- start-smoth-scrolling---->
		<script type="text/javascript" src="js/move-top.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript" src="date_heure.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
		 <!---- start-smoth-scrolling---->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts--->
		<link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic" rel="stylesheet" type="text/css" />
		<link href="http://fonts.googleapis.com/css?family=Playball" rel="stylesheet" type="text/css" />
		<!---//webfonts--->
		<!----start-top-nav-script---->
		<script>
			$(function() {
				var pull 		= $('#pull');
					menu 		= $('nav ul');
					menuHeight	= menu.height();
				$(pull).on('click', function(e) {
					e.preventDefault();
					menu.slideToggle();
				});
				$(window).resize(function(){
	        		var w = $(window).width();
	        		if(w > 320 && menu.is(':hidden')) {
	        			menu.removeAttr('style1');
	        		}
	    		});
			});
		</script>
		<!----//End-top-nav-script---->
	</head>
	<body>	
	<nav class="top-nav navbar-default navbar-right navbar-fixed-top" >
            <style>
                .top-nav{
                    height: 70px;
                }
            </style>
			<div id="home" class="header">
				
					<div class="top-header" >
					    <div class="logo">
						  <a href="grungeeng.php"><img src="images/Logo GRUNGE B.png" width="120" height="100" alt="GRUNGE" /></a>
						</div>
						<div class="container">
						
						<!----start-top-nav---->
						 
							<ul class="top-nav" style="float:left; margin-left:150px;">
								<li class="page-scroll"><a href="#banner" class="scroll">Home </a></li>
								<li class="page-scroll"><a href="#AboutUS" class="scroll">About Us</a></li>
								<li class="page-scroll"><a href="#banner_service" class="scroll">Services</a></li>
								<li class="page-scroll"><a href="http://www.sbcd-tn.com/catalogue-interactif/#p=1" target="_blank">catalogs</a></li>
								
								<li class="page-scroll"><a href="#team" class="scroll">Team</a></li>
								<li class="contatct-active" class="page-scroll"><a href="#banner_contact" class="scroll">Contact</a></li>
								<!----Horloge---->
								<script type="text/javascript">


                                function date_heure(id)
                                {
                                        date = new Date;
                                        annee = date.getFullYear();
                                        moi = date.getMonth();
                                        mois = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
                                        j = date.getDate();
                                        jour = date.getDay();
                                        jours = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
                                        h = date.getHours();
                                        if(h<10)
                                        {
                                                h = "0"+h;
                                        }
                                        m = date.getMinutes();
                                        if(m<10)
                                        {
                                                m = "0"+m;
                                        }
                                        s = date.getSeconds();
                                        if(s<10)
                                        {
                                                s = "0"+s;
                                        }
                                        resultat = jours[jour]+' '+j+' '+mois[moi]+' '+annee+' it is '+h+':'+m+':'+s;
                                        document.getElementById(id).innerHTML = resultat;
                                        setTimeout('date_heure("'+id+'");','1000');
                                        return true;
                                }
                                </script>
								 <!----//Horloge---->

								 
								 <!----LanguageSelector---->
								 
								 <div class="fc">
								 <a  class="fd" href="index.php"><img src="images/fa-fr.ico"></a>
								 <a  class="fe" href="grungeeng.php"><img src="images/fa-us.ico"></a></div>
								 </div>
								  <style> 
							     #date_heure, #date_heure:hover{
                                  	color: white;
                                  	position:fixed;
                                    top:90px;
                                    right:20px;
                                  }
                                  </style>
									<span id="date_heure" class="fa"></span>
							        <script type="text/javascript">window.onload = date_heure('date_heure'); </script>
                                 </div>
								 
								 <!---//LanguageSelector---->
								 </ul>
								 
								<!----IconSocialMedia---->
								<div id="mySidenav" class="sidenav">
								<a href="https://www.facebook.com/Grungetunis/"  target="_blank"  id="fb"><i style="float:left; margin-left:-10px;" class="fa fa-facebook" ></i></a>
								<a href="https://www.linkedin.com/in/grunge-communication-and-events-bb2b4b19b//" target="_blank"  id="link"><i  style="float:left; margin-left:-10px;" class="fa fa-linkedin"></i></a>
								</div>
								<!----//IconSocialMedia---->
								 

								
							<a href="#" id="pull"><img src="images/nav-icon.png" title="menu" /></a>
						</nav>
						<div class="clearfix"> </div>
						
					</div>
				</div>
			</div>
			<!----- //End-header---->
			<br>
			<br>
			<br>
			<br>
			<!----banner---->
			<div id="banner" class="banner text-center">
				<div class="container">
					<div class="banner-info">
						<label class="page-scroll"><a class="big-btn scroll" href="#AboutUS"><span> </span></a></label>
					</div>
				</div>
			</div>
			<!--//banner---->
			<!---QUI Sommes NOUS--->
			<div id="AboutUS" class="AboutUS">
				<div class="container">
					<div class="head-one text-center team-head">
					    <br>
						<br>
						<br>
				<br>
				<br>
						<h2>ABOUT US</h2>
						<style>
						    h2:hover{
                               font-size: 50px;
						    }
						</style>
							
						<p style="color:white;">Founded in 2013, the company GRUNGE Communication is an agency that meets all your communication needs, you are looking for the visibility, effectiveness, success ... Grunge is here! !
						</p>
						<p style="color:white;">From inception to meet the global communications needs of our valued customers, we have expanded our activities:</p>
						<p style="color:white;">Because each project is unique, we offer our customers a tailored solution that meets their requirements in artistic, technical and budget consistent with their overall communication strategy. </p>
							<p style="color:white;">Because each project is important, we involve our customers throughout the study, design and production phases of your site, web application, fair, event ...</p>
							<p style="color:white;"> Do you need a single agency that meets all your communication needs? It's us, it's Grunge! </p>
						</p>
					</div>	
				</div>
			</div>
			<!---//QUI SOMMES NOUS--->
			<!---work--->
				<br>
				<br>
				<br>
			
			<div id="banner_service" class="work"></div>
			    <div class="container">
				</div>
						<!-- Slideshow container -->
						<div class="slideshow-container">

							<!-- Full-width images with number and caption text -->
							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">1 / 6</div>
							<a href="creation graphique.html">
							<img  src="images/conception graphique services(s).png" title="Conception & design Graphique" class="image1" align="center" height="300" />
							<div class="overlay1">Conception & design Graphique</div>
						    </a>
							</div>
							</div>
						
							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">2 / 6</div>
							<a href="digital.html">
						    <img  src="images/DIGITAL  web GRUNGE.png" title="Digital" class="image1" align="center" height="300"/>
							<div class="overlay1">DIGITAL </div>
							</a>
							</div>
							</div>

							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">3 / 6</div>
							<a href="trade.html">
							<img  src="images/TRADE.png" title="TRADE"   class="image1" align="center" height="300"/>
							<div class="overlay1">TRADE </div>
							</a>
							</div>
							</div>

							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">4 / 6</div>
							<a href="print.html">
							<img  src="images/PRINT.png" title="PRINT" class="image1" align="center" height="300"/>
							<div class="overlay1">PRINT</div>
							</a>
							</div>
							</div>

							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">5 / 6</div>
							<a href="event.html">
							<img src="images/EVENT.png"  title="EVENT" class="image1" align="center" height="300"/>
							<div class="overlay1">EVENT</div>
							</a>
							</div>
							</div>

							<div class="mySlides fade">
							<div class="container1">
							<div class="numbertext">6 / 6</div>
							<a href="3D.html">
							<img  src="images/3D  web GRUNGE.png"  title="3D" class="image1" align="center" height="300"/>
							<div class="overlay1">3D</div>
							</a>
							</div>
							</div>



							<!-- Next and previous buttons -->
							<!--	<a class="prev" onclick="plusSlides(-1)">&#10094;</a> -->
							<!--	<a class="next" onclick="plusSlides(1)">&#10095;</a>-->
						<!--	</div> -->
						<br>
						
						<!-- The dots/circles -->
						<div style="text-align:center">
							<span class="dot" onclick="currentSlide(0)" title="Conception & Design Graphique"></span>
							<span class="dot" onclick="currentSlide(1)" title="Digital"></span>
							<span class="dot" onclick="currentSlide(2)" title="Trade"></span>
							<span class="dot" onclick="currentSlide(3)" title="Print"></span>
							<span class="dot" onclick="currentSlide(4)" title="Event"></span>
							<span class="dot" onclick="currentSlide(5)" title="3D"></span>
						</div>
									

			<script>
			var slideIndex = 1;
            showSlides(slideIndex);
            
           
            
            // Thumbnail image controls
            function currentSlide(n) {
              showSlides(slideIndex = n);
            }
            
            function showSlides(n) {
              var i;
              var slides = document.getElementsByClassName("mySlides");
              var dots = document.getElementsByClassName("dot");
              if (n > slides.length) {slideIndex = 1}
              if (n < 1) {slideIndex = slides.length}
              for (i = 0; i < slides.length; i++) {
                  slides[i].style.display = "none";
              }
              for (i = 0; i < dots.length; i++) {
                  dots[i].className = dots[i].className.replace("active", "");
              }
              slides[slideIndex-1].style.display = "block";
              dots[slideIndex-1].className += "active";
            }
            
            /*-----automatic slideshow-----*/
				var slideIndex = 0;
                showSlides();
                
                function showSlides() {
                  var i;
                  var slides = document.getElementsByClassName("mySlides");
                  for (i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";
                  }
                  slideIndex++;
                  if (slideIndex > slides.length) {slideIndex = 1}
                  slides[slideIndex-1].style.display = "block";
                  setTimeout(showSlides, 8000); // Change image every 8 seconds(8000 millisecondes)
                }  
				
			   </script>
			</div>
			<!---//works--->
					<!---team--->
					<div id="team" class="team">
						<div class="container">
							<div class="head-one text-center team-head">
							    <br>
							    <br>
							    <br>
								<h2>TEAM</h2>
								<span> </span>
								<p>We are a hard working group, who's aim is to listen to your problems and to come up with the best solution possible. We follow the lates trends on the web to create custom talierd niche websites.</p>
							</div>	
							<!----team-members---->
						<div class="team-members">
								<div class="col-md-3">
								    <style>
										    .t-pic:hover{
										        width: 100px;
                                                height: 100px;
										    }
										    
									</style>
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="manager" width="90" height="90" class="t-pic" title="name" />
										<h3>ISSAM BOUZAIDA</h3>
										<span>General Manager</span>
										<ul class="t-social unstyled-list list-inline">											
											<li><a class="in" href="https://www.linkedin.com/in/issam-bouzaida-4443a6121" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="Founder" width="90" height="90" class="t-pic"  />
										<h3>TAEIB TAHRI</h3>
										<span>Founder</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="#"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/avatar_director.jpg" alt="RH &amp; Marketing Director" width="90" height="90" class="t-pic" title="name" />
										<h3>JIHEN KAMMOUN</h3>
										<span>RH & Marketing Director</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="#"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="Commercial" width="90" height="90" class="t-pic" />
										<h3>Faical Rahmani</h3>
										<span>International Relations Officer</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="https://www.linkedin.com/in/faiçal-rahmani-97273040" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="Commercial" width="90" height="90" class="t-pic"  />
										<h3>Mehdi Ben Rhouma</h3>
										<span>Sales Manager</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="https://www.linkedin.com/in/mehdi-ben-rhouma-27aa223a" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="Commercial" width="90" height="90" class="t-pic" />
										
										<h3>Azzeddine Kettou</h3>
										<span>International Consultant</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="https://www.linkedin.com/in/azzeddine-kettou-351650114" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/avatar_director.jpg" alt="Web & Application Developer" width="90" height="90" class="t-pic" />
										
										<h3>Sywar Siala</h3>
										<span>Web Developer</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="https://www.linkedin.com/in/sywar-siala-8a75bb94/" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
								<div class="col-md-3">
									<div class="team-member text-center">
										<img src="images/img_avatar.png" alt="Graphic Designer" width="90" height="90" class="t-pic" />
										
										<h3>Fares mannai</h3>
										<span>Graphic Designer</span>
										<ul class="t-social unstyled-list list-inline">
											<li><a class="in" href="https://www.linkedin.com/in/fares-mannai-08838014b/" target="_blank"><span> </span></a></li>
											<div class="clearfix"> </div>
										</ul>
									</div>
								</div>
							</div>
							
							<!----//team-members---->
						</div>
					</div>
					<!---//team--->
					<!---Contact--->
				
					<div id="banner_contact" class="contact"></div>
					
							<div class="contact-grids">
								<div class="col-md-5 contact-map">
									<p style="color:white;">Where are we?</p>
									<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d6386.368853885453!2d10.181165499999993!3d36.83805890000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2stn!4v1579601952958!5m2!1sen!2stn" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>									
									</div>
								<div class="col-md-7 contact-form">
								    	<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSe9FQ4Umft08eTBQsDxvuYifkhnGRl8dD-bCPacAXxthOWKCw/viewform?embedded=true" width="640" height="844" frameborder="0" marginheight="0" marginwidth="0">Chargement…</iframe>
							<!--	<p>Do you want to contact us now? </p>

								<p>Simply send us a line below.</p>	
								<form action="" method="">
									<textarea name="textarea1">Leave us a message ...</textarea>
									<input type="text" name="Email" value="Your_email@mail.com">
									<input type="submit" value="    Send" />
																	</form> ---->
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
				
					<!---//Contact--->
					<!---footer--->
										<section class="footer">
					    	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"></span></a>
					    	<script type="text/javascript">
									$(document).ready(function() {
										
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
								
						    <tr>
								<p class="footer-left" style="float:left; margin-left:5px;">Adresse: 1 Rue jeune foyer, Etg1, AppA1,</br>
								 Immeuble Baraka, El Menzah 1 CP 1004</p>
								 
							    <p  class="footer-left" style="float:left; margin-left:250px;">Copyright&copy;2020 Grunge|Tous les droits sont r&eacute;serv&eacute;s</p>
							    
							   <a href="mailto:contact@grunge.com.tn"> <p class="footer-right" style="float:right; margin-right:5px;"> <strong>contact@grunge.com.tn</strong> </p></a> </br>
							   
								<p class="footer-right" style="float:right; margin-right:5px;">Tel:(+216) 71 235 631</p>
						    </tr>
							
							
							<div class="clearfix"> </div>
					</section>
					<!---//footer--->
				</div>
			</div>
			
	</body>
</html>